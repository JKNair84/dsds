import '@joint/plus/joint-plus.css';
import './styles.scss';
import { init } from './src/app';

init();
