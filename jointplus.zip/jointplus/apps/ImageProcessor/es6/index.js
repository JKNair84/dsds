import 'core-js/stable';
import 'regenerator-runtime/runtime';
import '@joint/plus/joint-plus.css';
import './styles.scss';
import { App } from './src/app';

export const app = new App();
